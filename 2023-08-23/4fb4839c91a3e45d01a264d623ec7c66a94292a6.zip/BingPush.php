<?php
$arr = array(
    'https://woyouwang.top' => array(//必应站长工具网站名称
        'url'  => array(
            "https://woyouwang.top/sitemap.xml"//你的网站地图
            ),
        'bing_key' => "你的必应api"
    ),
);


foreach ($arr as $i => $j) {
	//网站地址
    $website = $i;
    //站点地图
    $url = $j['url'];
    //必应key
    $bing_key = $j['bing_key'];
    
    //配额接口调用地址
    $quota_api = "https://ssl.bing.com/webmaster/api.svc/json/GetUrlSubmissionQuota?siteUrl=$website&apikey=$bing_key";
    
    //URL提交API接口调用地址
    $seturl_api = "https://ssl.bing.com/webmaster/api.svc/json/SubmitUrlBatch?apikey=$bing_key";
    
    $s = file_get_contents($quota_api);
    $s = json_decode($s, true);
    
    echo "$website 必应今日剩余配额：".$s['d']['DailyQuota']."  本月剩余配额：".$s['d']['MonthlyQuota'];echo '<br>';
    
    if($s['d']['DailyQuota']){
        $ch = curl_init();
        
        //防https错误
        $xmlresponse = curl_exec($ch);
        $xml=simplexml_load_string($xmlresponse);
        
        
        $urls = array();
        foreach ($url as $key => $value) {
            curl_setopt($ch, CURLOPT_URL, $value);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $xmlresponse = curl_exec($ch);
            $xml=simplexml_load_string($xmlresponse);
            
            foreach ($xml as $key => $value) {
            	$urls[] = $value->loc;
            }
            
        }
        shuffle($urls);
        //必应api提交每次上限100条
        if ($s['d']['DailyQuota']>=100) {
            $max = 100;
        } else {
            $max = $s['d']['DailyQuota'];
        }
        $urls = array_slice($urls, 0,$s['d']['DailyQuota']);
        if(!$urls){
            echo $website.' 今日配额已全部提交！';continue;
        }
        $url_data = array_chunk($urls, $max, true);
        
        foreach ($url_data as $key => $value) {
            $url_str = implode(',',$value);
            $url_arr = explode(',',$url_str);
            $data = array(
                "siteUrl"=>$website,
                "urlList"=>$url_arr
                );
            $ch = curl_init();
            $options =  array(
                CURLOPT_URL => $seturl_api,
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
            );
            curl_setopt_array($ch, $options);
            $result = curl_exec($ch);
            echo "$website 必应提交信息：".$result;echo '<br>';
        }
    }

}
?>